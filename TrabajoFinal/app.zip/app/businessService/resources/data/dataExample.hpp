#if !defined(DATA_EXAMPLE_HPP)
#define DATA_EXAMPLE_HPP

    namespace dataExample
    {
        void loadData();
    } // namespace dataExample

#endif // DATA_EXAMPLE_HP



