#if !defined(DATA_INVENTORY_EXAMPLE_HPP)
#define DATA_INVENTORY_EXAMPLE_HPP

    namespace dataInventoryExample
    {
        void loadData();
    } // namespace dataExample

#endif // DATA_INVENTORY_EXAMPLE_HP



